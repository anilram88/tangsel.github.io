<!-- footer content -->
<footer>
    <div class="pull-right">
        <span><a style="font-size: 17px; color:grey;">Copyright - 2022 Kecamatan Ciputat</a></span>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->